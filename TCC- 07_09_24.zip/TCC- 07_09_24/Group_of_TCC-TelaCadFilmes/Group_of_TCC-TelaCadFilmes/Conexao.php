<?php
$host="localhost";
$user="root";
$pass="";
$banco="genesflix";
$conexao=mysqli_connect($host, $user, $pass,
$banco) or die(mysql_error());
?>
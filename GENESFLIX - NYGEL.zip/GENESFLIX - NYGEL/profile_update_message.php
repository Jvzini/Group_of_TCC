<?php
$message = isset($_GET['message']) ? $_GET['message'] : 'Nenhuma mensagem.';
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualização do Perfil</title>
    <link rel="stylesheet" href="styles/styles_message.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url('img/blur_image.jpg');
            background-size: cover;
            /* Ajusta a imagem para cobrir todo o corpo */
            background-position: center;
            /* Centraliza a imagem */
            background-repeat: no-repeat;
            /* Evita que a imagem se repita */
        }

        .message-container {
            background: rgba(0, 0, 0, 0.85);
            /* Fundo mais escuro e opaco */
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.5);
            padding: 20px;
            text-align: center;
            max-width: 400px;
            width: 100%;
        }

        .message-container h1 {
            margin: 0;
            font-size: 24px;
            color: #ffffff;
            /* Cor do título ajustada */
        }

        .message-container p {
            font-size: 16px;
            margin: 20px 0;
            color: #e0e0e0;
            /* Cor do texto ajustada para contraste */
        }

        .message-container a {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: #ffffff;
            background-color: #13bfe1;
            /* Azul claro */
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .message-container a:hover {
            background-color: #094a5c;
            /* Azul escuro */
        }
    </style>
</head>

<body>
    <div class="message-container">
        <h1>Atualização do Perfil</h1>
        <p><?php echo htmlspecialchars($message); ?></p>
        <a href="logout.php">Voltar!</a>
    </div>
</body>

</html>
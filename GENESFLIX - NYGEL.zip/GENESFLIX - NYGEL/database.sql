CREATE DATABASE `genesflix`;

-- Seleciona o banco para ser utilizado
USE `genesflix`;

-- Tabela de gêneros
CREATE TABLE `genero` (
    `id` INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    `nome` VARCHAR(50) NOT NULL
);

-- Tabela de filmes
CREATE TABLE `filmes` (
    `id` INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    `titulo` VARCHAR(50) NOT NULL,
    `descricao` VARCHAR(80) NOT NULL,
    `ano` YEAR NOT NULL,
    `imagem` LONGBLOB  -- Armazena imagens em formato binário de grandes dimensões (até 4 GB)
);

-- Tabela de filmes e seus gêneros
CREATE TABLE `filmes_genero` (
    `id_genero` INT NOT NULL,
    `id_filmes` INT NOT NULL,
    PRIMARY KEY (`id_genero`, `id_filmes`)
);

-- Tabela de usuários
CREATE TABLE `users` (
    `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `full_name` VARCHAR(128) NOT NULL,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `data_cadastro` DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabela de relacionamento entre usuário e filmes
CREATE TABLE `users_filmes` (
    `id_usuario` INT NOT NULL,
    `id_filmes` INT NOT NULL,
    PRIMARY KEY (`id_usuario`, `id_filmes`)
);

-- Tabela de avaliações
CREATE TABLE `avaliacao` (
    `id` INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    `nota` CHAR(1) NOT NULL,
    `data` DATE NOT NULL,
    `filmes_avaliacao` INT NOT NULL,
    `usuario_avaliacao` INT NOT NULL
);

-- Criação das foreign keys
ALTER TABLE `users_filmes`
    ADD CONSTRAINT `fk_usuario_ass_filme` FOREIGN KEY (`id_filmes`)
    REFERENCES `filmes`(`id`);

ALTER TABLE `users_filmes`
    ADD CONSTRAINT `fk_filmes_tem_usuario` FOREIGN KEY (`id_usuario`)
    REFERENCES `users`(`id`);

ALTER TABLE `avaliacao`
    ADD CONSTRAINT `fk_usuario_faz_ava` FOREIGN KEY (`usuario_avaliacao`)
    REFERENCES `users`(`id`);

ALTER TABLE `avaliacao`
    ADD CONSTRAINT `fk_filmes_tem_ava` FOREIGN KEY (`filmes_avaliacao`)
    REFERENCES `filmes`(`id`);

ALTER TABLE `filmes_genero`
    ADD CONSTRAINT `fk_filmes_tem_genero` FOREIGN KEY (`id_filmes`)
    REFERENCES `filmes`(`id`);

ALTER TABLE `filmes_genero`
    ADD CONSTRAINT `fk_genero` FOREIGN KEY (`id_genero`)
    REFERENCES `genero`(`id`);

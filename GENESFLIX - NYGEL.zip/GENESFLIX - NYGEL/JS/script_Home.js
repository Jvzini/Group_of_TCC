document.addEventListener('DOMContentLoaded', function () {
    // Carregar filmes via fetch
    fetch('Home.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const filmeContainer = document.querySelector('.filme-container');
                data.filmes.forEach(filme => {
                    const filmeDiv = document.createElement('div');
                    filmeDiv.className = 'filme';
                    filmeDiv.dataset.id = filme.id;
                    filmeDiv.dataset.titulo = filme.titulo;
                    filmeDiv.dataset.descricao = filme.descricao;
                    filmeDiv.dataset.dataLancamento = filme.ano;
                    filmeDiv.dataset.genero = filme.genero;
                    filmeDiv.dataset.mediaAvaliacao = filme.media_avaliacao;

                    filmeDiv.innerHTML = `
                        <img src="data:image/jpeg;base64,${filme.imagem}" alt="${filme.titulo}">
                        <h2>${filme.titulo}</h2>
                        <p>Nota: ${parseFloat(filme.media_avaliacao).toFixed(2)}</p>
                    `;
                    filmeContainer.appendChild(filmeDiv);
                });
            } else {
                console.error('Erro ao carregar filmes');
            }
        })
        .catch(error => console.error('Erro:', error));

    // Seleciona todos os elementos de filmes
    const modal = document.getElementById('filmeModal');
    const closeModal = document.getElementById('closeModal');
    const modalTitulo = document.getElementById('modalTitulo');
    const modalGenero = document.getElementById('modalGenero');
    const modalDataLancamento = document.getElementById('modalDataLancamento');
    const modalDescricao = document.getElementById('modalDescricao');
    const modalNota = document.getElementById('modalNota');
    const playButton = document.getElementById('playButton');
    const stars = document.querySelectorAll('.star');
    const ratingValue = document.getElementById('rating-value');
    const submitRating = document.getElementById('submit-rating');
    let selectedRating = 0;

    // Função para resetar a avaliação
    function resetRating() {
        ratingValue.textContent = '0';
        selectedRating = 0;
        stars.forEach(star => star.classList.remove('active'));
    }

    // Adiciona listeners para estrelas de avaliação
    stars.forEach(star => {
        star.addEventListener('click', () => {
            const rating = star.getAttribute('data-value');
            ratingValue.textContent = rating;
            selectedRating = rating;
            stars.forEach(s => s.classList.remove('active'));
            for (let i = 0; i < rating; i++) {
                stars[i].classList.add('active');
            }
        });
    });

    // Itera sobre cada filme e adiciona evento de clique para abrir o modal
    document.querySelector('.filme-container').addEventListener('click', e => {
        const filme = e.target.closest('.filme');
        if (filme) {
            const titulo = filme.dataset.titulo;
            const descricao = filme.dataset.descricao;
            const dataLancamento = filme.dataset.dataLancamento;
            const genero = filme.dataset.genero;
            const mediaAvaliacao = parseFloat(filme.dataset.mediaAvaliacao); // Converte para número
    
            modalTitulo.textContent = titulo;
            modalGenero.innerHTML = `<strong>Gênero:</strong> ${genero}`;
            modalDataLancamento.innerHTML = `<strong>Lançamento:</strong> ${dataLancamento}`;
            modalDescricao.innerHTML = `<strong>Descrição:</strong> ${descricao}`;
            modalNota.innerHTML = `<strong>Nota Média:</strong> ${isNaN(mediaAvaliacao) ? 'N/A' : mediaAvaliacao.toFixed(2)}`; // Aplica toFixed
    
            resetRating();
    
            modal.classList.add('show');
        }
    });
    

    // Enviar a avaliação
    submitRating.addEventListener('click', () => {
        const rating = ratingValue.textContent;
        const filmeTitulo = modalTitulo.textContent;

        if (rating === '0') {
            alert('Por favor, escolha uma estrela para enviar a avaliação.');
            return;
        }

        fetch('submit_rating.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                rating: rating,
                filme: filmeTitulo
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Avaliação enviada com sucesso!');
            } else {
                alert('Erro ao enviar avaliação.');
            }
        })
        .catch((error) => {
            console.error('Erro:', error);
            alert('Ocorreu um erro ao enviar a avaliação.');
        });
    });

    // Fechar o modal ao clicar no botão X
    closeModal.addEventListener('click', () => {
        modal.classList.remove('show');
    });

    // Fechar o modal ao clicar fora do conteúdo
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('show');
        }
    });

    // Iniciar o filme (substituir com lógica para iniciar o filme)
    playButton.addEventListener('click', () => {
        alert('Iniciando o filme...');
    });
});

<?php
include 'conexao.php';

// Insere os gêneros no banco de dados, caso ainda não estejam inseridos
$sqlCheck = "SELECT COUNT(*) as total FROM genero";
$resultCheck = mysqli_query($conn, $sqlCheck);
$rowCheck = mysqli_fetch_assoc($resultCheck);

if ($rowCheck['total'] == 0) {
    // Inserir os gêneros
    $sqlInsertGenres = "INSERT INTO genero (nome) VALUES ('Horror'), ('Fantasia'), ('Comédia')";
    mysqli_query($conn, $sqlInsertGenres);
}

// Variável para armazenar a mensagem de status
$statusMessage = '';

// Verifica se o formulário foi submetido
if (isset($_POST['submit'])) {
    // Captura os dados do formulário
    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao'];
    $ano = $_POST['ano'];
    $id_genero = $_POST['genero']; // Captura o gênero selecionado

    // Verifica se a imagem foi enviada sem erros
    if ($_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
        // Obtém o caminho temporário do arquivo de imagem
        $imagemTmp = $_FILES['imagem']['tmp_name'];

        // Lê o conteúdo da imagem em formato binário
        $imagemConteudo = file_get_contents($imagemTmp);

        // Prepara a instrução SQL para inserir os dados na tabela 'filmes'
        $sql = "INSERT INTO filmes (titulo, descricao, ano, imagem) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssis", $titulo, $descricao, $ano, $imagemConteudo);

        // Executa a instrução SQL e obtém o ID do filme inserido
        if (mysqli_stmt_execute($stmt)) {
            $id_filme = mysqli_insert_id($conn); // Obtém o ID do filme recém cadastrado

            // Relaciona o filme com o gênero selecionado na tabela 'filmes_genero'
            $sqlGenero = "INSERT INTO filmes_genero (id_genero, id_filmes) VALUES (?, ?)";
            $stmtGenero = mysqli_prepare($conn, $sqlGenero);
            mysqli_stmt_bind_param($stmtGenero, "ii", $id_genero, $id_filme);

            if (mysqli_stmt_execute($stmtGenero)) {
                $statusMessage = "<div class='alert alert-success'>Filme cadastrado com sucesso com gênero!</div>";
            } else {
                $statusMessage = "<div class='alert alert-danger'>Erro ao relacionar o gênero ao filme.</div>";
            }
        } else {
            $statusMessage = "<div class='alert alert-danger'>Erro ao cadastrar o filme.</div>";
        }
    } else {
        $statusMessage = "<div class='alert alert-danger'>Erro ao enviar a imagem.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Filmes - GenesFlix</title>
    <link rel="stylesheet" href="styles/styles_file.CSS">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url('img/blur_image.jpg');
            background-size: cover;
            /* Ajusta a imagem para cobrir todo o corpo */
            background-position: center;
            /* Centraliza a imagem */
            background-repeat: no-repeat;
            /* Evita que a imagem se repita */
        }
    </style>
</head>

<body>
    <div class="registration-container">
        <div class="registration-form">
            <!-- Exibe o logotipo do site -->
            <div class="icon-container">
                <img src="img/Gear_Movie.png" alt="Logo" class="logo">
            </div>

            <!-- Título do formulário -->
            <h2>CADASTRAR FILME:</h2>

            <!-- Formulário de cadastro de filme -->
            <form action="" method="post" enctype="multipart/form-data">
                <!-- Campo para o título do filme -->
                <div class="form-group">
                    <input type="text" class="form-control" name="titulo" placeholder="Título do Filme" required>
                </div>

                <!-- Campo para a descrição do filme -->
                <div class="form-group">
                    <textarea class="form-control" name="descricao" placeholder="Descrição" required></textarea>
                </div>

                <!-- Campo para o ano de lançamento -->
                <div class="form-group">
                    <input type="number" class="form-control" name="ano" placeholder="Ano de Lançamento" required>
                </div>

                <!-- Campo para a seleção do gênero -->
                <div class="form-group">
                    <label for="genero">Gênero:</label>
                    <select class="form-control" name="genero" required>
                        <option value="">Selecione o Gênero</option>
                        <?php
                        // Busca os gêneros cadastrados no banco de dados
                        $sqlGenero = "SELECT id, nome FROM genero";
                        $resultGenero = mysqli_query($conn, $sqlGenero);

                        // Preenche o select com os gêneros
                        while ($row = mysqli_fetch_assoc($resultGenero)) {
                            echo "<option value='" . $row['id'] . "'>" . $row['nome'] . "</option>";
                        }
                        ?>
                    </select>
                </div>

                <!-- Campo para o upload da imagem do filme -->
                <div class="form-group">
                    <label for="imagem">Selecione a Imagem:</label>
                    <input type="file" name="imagem" accept="image/*" required>
                    <br>
                    <button type="button" id="remove-image" style="display:none;">❌</button>
                </div>

                <!-- Botão de submissão do formulário -->
                <div class="form-btn">
                    <input type="submit" class="btn btn-primary" value="Cadastrar" name="submit">
                </div>
            </form>
        </div>
    </div>

    <!-- Exibe a mensagem de status abaixo do contêiner -->
    <div class="status-message">
        <?php echo $statusMessage; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Seleciona o formulário e os campos necessários
            const form = document.querySelector('form');
            const imageInput = document.querySelector('input[type="file"]');
            const imagePreview = document.createElement('img');
            const removeButton = document.getElementById('remove-image');

            imagePreview.style.maxWidth = '40%';
            imagePreview.style.marginTop = '0px';

            // Adiciona um ouvinte de evento para a mudança no input de imagem
            imageInput.addEventListener('change', function(event) {
                const file = event.target.files[0];

                // Verifica se o arquivo é uma imagem válida
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();

                    // Quando o arquivo for carregado, define a fonte da imagem de pré-visualização
                    reader.onload = function(e) {
                        imagePreview.src = e.target.result;
                        removeButton.style.display = 'block'; // Exibe o botão de excluir
                    };

                    reader.readAsDataURL(file);
                } else {
                    alert('Por favor, selecione um arquivo de imagem válido.');
                    imageInput.value = ''; // Reseta o input se o arquivo não for válido
                }
            });

            // Adiciona a pré-visualização da imagem e o botão de excluir após o campo de upload
            imageInput.parentNode.appendChild(imagePreview);

            // Adiciona um ouvinte de evento para o botão de excluir imagem
            removeButton.addEventListener('click', function() {
                imagePreview.src = '';
                imageInput.value = ''; // Reseta o campo de upload
                removeButton.style.display = 'none'; // Oculta o botão de excluir
            });

            // Validação do formulário antes do envio
            form.addEventListener('submit', function(event) {
                const titulo = form.querySelector('input[name="titulo"]').value.trim();
                const descricao = form.querySelector('textarea[name="descricao"]').value.trim();
                const ano = form.querySelector('input[name="ano"]').value.trim();
                const imagem = imageInput.files[0];

                let valid = true;

                // Verifica se todos os campos obrigatórios foram preenchidos
                if (!titulo || !descricao || !ano || !imagem) {
                    alert('Por favor, preencha todos os campos e selecione uma imagem.');
                    valid = false;
                }

                // Verifica se o ano é um número válido e dentro de uma faixa aceitável
                const currentYear = new Date().getFullYear();
                if (ano < 1888 || ano > currentYear) { // Cinema começou em 1888
                    alert('Por favor, insira um ano válido entre 1888 e o ano atual.');
                    valid = false;
                }

                // Verifica se o arquivo de imagem é válido
                if (imagem && !imagem.type.startsWith('image/')) {
                    alert('Por favor, selecione um arquivo de imagem válido.');
                    valid = false;
                }

                // Se o formulário não for válido, impede o envio
                if (!valid) {
                    event.preventDefault();
                }
            });
        });
    </script>

</body>

</html>
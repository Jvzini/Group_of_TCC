<?php
include 'conexao.php'; 

// Verifica se o formulário foi submetido
if (isset($_POST['submit'])) {
    // Captura os dados do formulário
    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao'];
    $ano = $_POST['ano'];

    // Verifica se a imagem foi enviada sem erros
    if ($_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
        // Obtém o caminho temporário do arquivo de imagem
        $imagemTmp = $_FILES['imagem']['tmp_name'];

        // Lê o conteúdo da imagem em formato binário
        $imagemConteudo = file_get_contents($imagemTmp); 

        // Prepara a instrução SQL para inserir os dados no banco
        $sql = "INSERT INTO filmes (titulo, descricao, ano, imagem) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);

        // Liga os parâmetros à instrução SQL
        mysqli_stmt_bind_param($stmt, "ssis", $titulo, $descricao, $ano, $imagemConteudo);

        // Executa a instrução SQL
        if (mysqli_stmt_execute($stmt)) {
            echo "<div class='alert alert-success'>Filme cadastrado com sucesso!</div>";
        } else {
            echo "<div class='alert alert-danger'>Erro ao cadastrar o filme.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Erro ao enviar a imagem.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Filmes - GenesFlix</title>
    <link rel="stylesheet" href="styles_file.CSS">
</head>

<body>
    <div class="registration-container">
        <div class="registration-form">
            <!-- Exibe o logotipo do site -->
            <div class="icon-container">
                <img src="img/Gear_Movie.png" alt="Logo" class="logo">
            </div>
            
            <!-- Título do formulário -->
            <h2>CADASTRAR FILME:</h2>

            <!-- Formulário de cadastro de filme -->
            <form action="" method="post" enctype="multipart/form-data">
                <!-- Campo para o título do filme -->
                <div class="form-group">
                    <input type="text" class="form-control" name="titulo" placeholder="Título do Filme" required>
                </div>

                <!-- Campo para a descrição do filme -->
                <div class="form-group">
                    <textarea class="form-control" name="descricao" placeholder="Descrição" required></textarea>
                </div>

                <!-- Campo para o ano de lançamento -->
                <div class="form-group">
                    <input type="number" class="form-control" name="ano" placeholder="Ano de Lançamento" required>
                </div>

                <!-- Campo para o upload da imagem do filme -->
                <div class="form-group">
                    <label for="imagem">Selecione a Imagem:</label>
                    <input type="file" name="imagem" accept="image/*" required>
                    <br>
                    <button type="button" id="remove-image" style="display:none;">❌</button>
                </div>

                <!-- Botão de submissão do formulário -->
                <div class="form-btn">
                    <input type="submit" class="btn btn-primary" value="Cadastrar" name="submit">
                </div>
            </form>
        </div>
    </div>
  <script>
document.addEventListener('DOMContentLoaded', function () {
    // Seleciona o formulário e os campos necessários
    const form = document.querySelector('form');
    const imageInput = document.querySelector('input[type="file"]');
    const imagePreview = document.createElement('img');
    const removeButton = document.getElementById('remove-image');
    
    imagePreview.style.maxWidth = '40%';
    imagePreview.style.marginTop = '0px';

    // Adiciona um ouvinte de evento para a mudança no input de imagem
    imageInput.addEventListener('change', function (event) {
        const file = event.target.files[0];

        // Verifica se o arquivo é uma imagem válida
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();

            // Quando o arquivo for carregado, define a fonte da imagem de pré-visualização
            reader.onload = function (e) {
                imagePreview.src = e.target.result;
                removeButton.style.display = 'block'; // Exibe o botão de excluir
            };

            reader.readAsDataURL(file);
        } else {
            alert('Por favor, selecione um arquivo de imagem válido.');
            imageInput.value = '';  // Reseta o input se o arquivo não for válido
        }
    });

    // Adiciona a pré-visualização da imagem e o botão de excluir após o campo de upload
    imageInput.parentNode.appendChild(imagePreview);
    
    // Adiciona um ouvinte de evento para o botão de excluir imagem
    removeButton.addEventListener('click', function () {
        imagePreview.src = '';
        imageInput.value = ''; // Reseta o campo de upload
        removeButton.style.display = 'none'; // Oculta o botão de excluir
    });

    // Validação do formulário antes do envio
    form.addEventListener('submit', function (event) {
        const titulo = form.querySelector('input[name="titulo"]').value.trim();
        const descricao = form.querySelector('textarea[name="descricao"]').value.trim();
        const ano = form.querySelector('input[name="ano"]').value.trim();
        const imagem = imageInput.files[0];

        let valid = true;

        // Verifica se todos os campos obrigatórios foram preenchidos
        if (!titulo || !descricao || !ano || !imagem) {
            alert('Por favor, preencha todos os campos e selecione uma imagem.');
            valid = false;
        }

        // Verifica se o ano é um número válido e dentro de uma faixa aceitável
        const currentYear = new Date().getFullYear();
        if (ano < 1888 || ano > currentYear) {  // Cinema começou em 1888
            alert('Por favor, insira um ano válido entre 1888 e o ano atual.');
            valid = false;
        }

        // Verifica se o arquivo de imagem é válido
        if (imagem && !imagem.type.startsWith('image/')) {
            alert('Por favor, selecione um arquivo de imagem válido.');
            valid = false;
        }

        // Se o formulário não for válido, impede o envio
        if (!valid) {
            event.preventDefault();
        }
    });
});
  </script>

</body>

</html>

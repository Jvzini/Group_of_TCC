<?php
session_start();
require 'conexao.php'; // Arquivo que faz a conexão com o banco

// Verifique se o usuário está logado
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

// Pegue o ID do usuário logado
$user_id = $_SESSION['user'];

// Buscar os dados do usuário
$sql_user = "SELECT full_name, email, profile_picture, role FROM users WHERE id = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result_user = $stmt->get_result();

// Verifica se há resultados para o usuário
if ($result_user->num_rows > 0) {
    $user = $result_user->fetch_assoc();
} else {
    echo "Erro: Usuário não encontrado!";
    exit();
}

// Buscar os dados dos filmes e suas médias de avaliação
$sql_filmes = "SELECT filmes.imagem, filmes.titulo, filmes.descricao, filmes.ano, genero.nome AS genero,
               IFNULL(AVG(avaliacao.nota), 0) AS media_avaliacao
               FROM filmes
               JOIN filmes_genero ON filmes.id = filmes_genero.id_filmes
               JOIN genero ON filmes_genero.id_genero = genero.id
               LEFT JOIN avaliacao ON filmes.id = avaliacao.filmes_avaliacao
               GROUP BY filmes.id";
$stmt = $conn->prepare($sql_filmes);
$stmt->execute();
$result_filmes = $stmt->get_result();

// Verifica se há resultados para os filmes
if ($result_filmes->num_rows > 0) {
    $imagens = array();
    while ($row = $result_filmes->fetch_assoc()) {
        $imagem_blob = $row['imagem'];
        $titulo = $row['titulo'];
        $descricao = $row['descricao'];
        $ano = $row['ano'];
        $genero = $row['genero'];
        $media_avaliacao = $row['media_avaliacao'];

        // Verifica se a imagem é válida
        if (strlen($imagem_blob) > 0 && is_string($imagem_blob)) {
            $imagens[] = array(
                'imagem' => base64_encode($imagem_blob),
                'titulo' => $titulo,
                'descricao' => $descricao,
                'ano' => $ano,
                'genero' => $genero,
                'media_avaliacao' => $media_avaliacao
            );
        }
    }
} else {
    http_response_code(404); // Retorna um erro 404 se não houver resultados
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GenesFlix</title>
    <link rel="stylesheet" href="styles/home_styles.css">
    <style>
        /* Estilo do modal de detalhes */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            background-color: #1c1c1c;
            padding: 30px;
            border-radius: 10px;
            width: 80%;
            max-width: 1000px;
            position: relative;
        }

        .modal-content h2 {
            color: #fff;
        }

        .modal-content p {
            color: #ccc;
        }

        .close-modal {
            position: absolute;
            top: 10px;
            right: 20px;
            background: none;
            border: none;
            font-size: 25px;
            color: white;
            cursor: pointer;
        }

        .play-button {
            display: inline-block;
            background-color: #6106f4;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 20px;
        }

        .play-button:hover {
            background-color: #6106f471;
        }

        /* Estilos para o sistema de avaliação */
        .rating-container {
            text-align: left;
            background-color: #2d2d2d;
            /* Cinza escuro */
            padding: 20px;
            border-radius: 8px;
            color: white;
            margin-top: 20px;
        }

        .stars {
            display: flex;
            justify-content: left;
            gap: 10px;
        }

        .star {
            font-size: 25px;
            cursor: pointer;
            color: #ccc;
            /* Cinza por padrão */
            transition: color 0.3s;
        }

        .star:hover,
        .star.active {
            color: #ffc107;
            /* Amarelo para estrelas selecionadas */
        }

        .rating-text {
            margin-top: 15px;
            font-size: 15px;
        }

        #submit-rating {
            background-color: #6106f4;
            /* Mesma cor do botão de 'Assistir' */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        #submit-rating:hover {
            background-color: #4b04b9;
            /* Cor mais escura ao passar o mouse */
        }

        /* Ajuste para alinhar o botão */
        .rating-container {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            margin-top: 20px;
        }

        .estrela {
            color: yellow;
            font-size: 1em;
            /* Menor que o original */
            vertical-align: baseline;
            margin-right: 5px;
        }

        .filme p {
            font-size: 1em;
            font-weight: bold;
            /* Aplica negrito */
            color: #555;
            display: flex;
            align-items: center;
            /* Adiciona um pouco de espaço entre o texto e a borda do container */
            margin: 0;
        }

        .filme {
            position: relative;
            padding: 10px;
            border: 1px solid black;
            border-radius: 8px;
            margin: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .btn {
            text-align: center;
        }

        .btn-link {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: rgb(0, 0, 0);
            background-color: #eeff00;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn-link:hover {
            background-color: #eeff0088;
            transform: scale(1.05);
        }

        .btn-link:active {
            background-color: #eeff00c9;
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="header-left">
            <img src="img/logo_title.png">
        </div>
        <nav class="navbar">
            <a href="Home.php">Início</a>
            <a href="#">Originais</a>
            <a href="#">Adicionados recentemente</a>
            <a href="#">Minha lista</a>
        </nav>
        <div class="search-bar">
            <span class="search-icon">🔎</span>
            <input type="text" class="search-input" placeholder="legendas em português">
        </div>
        <div class="user-info">
            <h4 class="user-name"><?php echo htmlspecialchars($user['full_name']); ?></h4>
            <div class="header-right color-border">
                <a href="profile.php">
                    <?php
                    $imgData = base64_encode($user['profile_picture']);
                    ?>
                    <img src="data:image/jpeg;base64,<?php echo $imgData; ?>" alt="Foto de Perfil" class="profile-thumbnail">
                </a>
            </div>
        </div>
    </div>
    <br><br>

    <main>
        <div class="filme-container">
            <?php foreach ($imagens as $imagem) { ?>
                <div class="filme" data-titulo="<?= htmlspecialchars($imagem['titulo']) ?>" data-descricao="<?= htmlspecialchars($imagem['descricao']) ?>" data-data-lancamento="<?= htmlspecialchars($imagem['ano']) ?>" data-genero="<?= htmlspecialchars($imagem['genero']) ?>">
                    <img src="data:image/jpeg;base64,<?= $imagem['imagem'] ?>" alt="<?= htmlspecialchars($imagem['titulo']) ?>">
                    <h2><?= htmlspecialchars($imagem['titulo']) ?></h2>
                    <p><span class="estrela">&#9733;</span><?= number_format($imagem['media_avaliacao'], 2) ?></p> <!-- Exibindo a média -->
                </div>
            <?php } ?>
        </div>
    </main>

    <!-- Modal de Detalhes -->
    <div class="modal" id="filmeModal">
        <div class="modal-content">
            <button class="close-modal" id="closeModal">&times;</button>
            <h2 id="modalTitulo"></h2>
            <p id="modalGenero"></p>
            <p id="modalDataLancamento"></p>
            <p id="modalDescricao"></p>
            <p id="modalNota"></p> <!-- Novo elemento para a nota média -->
            <button class="play-button" id="playButton">Assistir</button>
            <!-- Contêiner de avaliação -->
            <div class="rating-container">
                <h3>Avalie este filme:</h3>
                <div class="stars">
                    <span class="star" data-value="1">&#9733;</span>
                    <span class="star" data-value="2">&#9733;</span>
                    <span class="star" data-value="3">&#9733;</span>
                    <span class="star" data-value="4">&#9733;</span>
                    <span class="star" data-value="5">&#9733;</span>
                </div>
                <p class="rating-text">Sua Avaliação: <span id="rating-value">0</span> estrela(s)</p>
            </div>
            <button id="submit-rating">Enviar Avaliação</button>
        </div>
    </div>
    <br>
    <div class="botao">
        <a href="logout.php" class="button-link">Sair</a>
    </div>
    <br>
    <div class="btn">
        <?php if ($user['role'] == 'admin') : ?>
            <a href="cadastro_de_filme.php" class="btn-link">Opção de Admin: Cadastrar Filme</a>
        <?php endif; ?>
    </div>
    <br>
    <footer class="footer">
        <p>&copy; 2024 GenesFlix, Inc. <a href="#">Política de Privacidade</a> • <a href="#">Termos de Serviço</a></p>
    </footer>

    <script src="JS/script_Home.js"></script>


</body>

</html>
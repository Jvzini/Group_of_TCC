<?php
session_start();
if (!isset($_SESSION["user"])) {
   header("Location: login.php");
}
include 'conexao.php';

// Prepara a consulta SQL
$sql = "SELECT imagem, titulo, descricao, ano FROM filmes";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

// Verifica se há resultados
if ($result->num_rows > 0) {
    $imagens = array();
    while ($row = $result->fetch_assoc()) {
        $imagem_blob = $row['imagem'];
        $titulo = $row['titulo'];
        $descricao = $row['descricao'];
        $ano = $row['ano'];

        // Verifica se a imagem é válida
        if (strlen($imagem_blob) > 0 && is_string($imagem_blob)) {
            $imagens[] = array(
                'imagem' => base64_encode($imagem_blob),
                'titulo' => $titulo,
                'descricao' => $descricao,
                'ano' => $ano
            );
        }
    }
} else {
    http_response_code(404); // Retorna um erro 404 se não houver resultados
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="home_styles.css">
    <script src="script_inicial.js" defer></script>
    <title>GenesFlix</title>
    <style>
        .botao {
            text-align: center;
        }
        .button-link {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s, transform 0.3s;
        }

        .button-link:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        .button-link:active {
            background-color: #00408d;
        }
        .netflix-footer {
            background: linear-gradient(135deg, #0d0d2b, #191970);
            color: #fff; /* Cor do texto */
            text-align: center; /* Centraliza o texto */
            padding: 20px; /* Adiciona espaçamento interno */
            position: relative; /* Mantém o rodapé fixo na parte inferior */
            width: 100%; /* Faz o rodapé ocupar toda a largura da tela */
            bottom: 0; /* Alinha o rodapé na parte inferior da tela */
            font-size: 14px; /* Tamanho da fonte */
            border-top: 1px solid #333; /* Borda superior sutil */

        }

        .netflix-footer p {
            margin: 3; /* Remove a margem padrão do parágrafo */
        }

        .netflix-footer a {
            color: #1db954; /* Cor dos links */
            text-decoration: none; /* Remove o sublinhado dos links */
        }

        .netflix-footer a:hover {
            text-decoration: underline; /* Sublinha o link ao passar o mouse */
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="header-left">🧬GenesFlix</div>
        <nav class="netflix-nav">
            <a href="#">Início</a>
            <a href="#">Séries</a>
            <a href="#">Filmes</a>
            <a href="#">Originais</a>
            <a href="#">Adicionados recentemente</a>
            <a href="#">Minha lista</a>
        </nav>
        <div class="search-bar">
            <span class="search-icon">🔎</span>
            <input type="text" class="search-input" placeholder="legendas em português">
        </div>
        <div class="header-right color-border">
            <img src="img/dna.png" alt="Perfil">
        </div>
    </div>
<br>
<br>
    <main>
        <div class="filme-container">
            <?php foreach ($imagens as $imagem) { ?>
                <div class="filme" data-titulo="<?= htmlspecialchars($imagem['titulo']) ?>" data-descricao="<?= htmlspecialchars($imagem['descricao']) ?>" data-data-lancamento="<?= htmlspecialchars($imagem['ano']) ?>">
                    <img src="data:image/jpeg;base64,<?= $imagem['imagem'] ?>" alt="<?= htmlspecialchars($imagem['titulo']) ?>">
                    <h2><?= htmlspecialchars($imagem['titulo']) ?></h2>
                </div>
            <?php } ?>
        </div>

        <div class="filme-detalhes" id="filme-detalhes">
            <h2 id="filme-titulo"></h2>
            <p id="filme-data-lancamento"></p>
            <p id="filme-descricao"></p>
        </div>
    </main>
<br>
    <div class="botao">
        <a href="logout.php" class="button-link">Sair</a>
    </div>
<br>
<br>
    <footer class="netflix-footer">
        <p>&copy; 2024 GenesFlix, Inc.</p>
    </footer>

    <script>
        const filmes = document.querySelectorAll('.filme');
        const filmeDetalhes = document.getElementById('filme-detalhes');

        filmes.forEach(filme => {
            filme.addEventListener('click', () => {
                const titulo = filme.getAttribute('data-titulo');
                const descricao = filme.getAttribute('data-descricao');
                const dataLancamento = filme.getAttribute('data-data-lancamento');

                filmeDetalhes.innerHTML = `
                    <h2 id="filme-titulo">${titulo}</h2>
                    <p id="filme-data-lancamento">Data de Lançamento: ${dataLancamento}</p>
                    <p id="filme-descricao">${descricao}</p>
                `;

                filmeDetalhes.classList.add('show');
            });
        });

        document.addEventListener('click', (e) => {
            if (!e.target.closest('.filme') && !filmeDetalhes.contains(e.target)) {
                filmeDetalhes.classList.remove('show');
            }
        });
    </script>
</body>

</html>

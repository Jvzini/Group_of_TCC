<?php
session_start();
require 'conexao.php'; // Arquivo que faz a conexão com o banco

// Verifique se o usuário está logado
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

// Pegue o ID do usuário logado
$user_id = $_SESSION['user'];

// Busque os dados do usuário no banco de dados
$sql = "SELECT full_name, email, profile_picture FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Se os dados forem encontrados, armazene-os em uma variável
    $user = $result->fetch_assoc();
} else {
    echo "Erro: Usuário não encontrado!";
    exit();
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil do Usuário</title>
    <link rel="stylesheet" href="styles/styles_Perfil.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url('img/blur_image.jpg');
            background-size: cover;
            /* Ajusta a imagem para cobrir todo o corpo */
            background-position: center;
            /* Centraliza a imagem */
            background-repeat: no-repeat;
            /* Evita que a imagem se repita */
        }
    </style>
</head>

<body>
    <div class="profile-container">
        <div class="profile-header">
            <?php
            // Exibe a imagem do perfil em base64
            $imgData = base64_encode($user['profile_picture']);
            ?>
            <img src="data:image/jpeg;base64,<?php echo $imgData; ?>" alt="Foto de Perfil" class="profile-picture">
            <h1><?php echo htmlspecialchars($user['full_name']); ?></h1>
        </div>
        <div class="profile-details">
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
        </div>
        <button id="edit-profile-btn">Editar Perfil</button>

        <div id="edit-form" class="hidden">
            <form action="update_profile.php" method="POST">
                <label for="name">Nome:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['full_name']); ?>">

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">

                <button type="submit">Salvar</button>
            </form>
            <br>
            <!-- Botão para excluir os dados -->
            <form action="delete_profile.php" method="POST" onsubmit="return confirm('Tem certeza que deseja excluir seus dados?');">
                <button type="submit">Excluir Dados</button>
            </form>
        </div>
    </div>
    <script>
        document.getElementById('edit-profile-btn').addEventListener('click', function() {
            var form = document.getElementById('edit-form');
            form.classList.toggle('hidden');
        });
    </script>
</body>

</html>
<?php
session_start();
require 'conexao.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user'];

// Buscar os dados do usuário
$sql_user = "SELECT full_name, email, profile_picture, role FROM users WHERE id = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result_user = $stmt->get_result();

if ($result_user->num_rows > 0) {
    $user = $result_user->fetch_assoc();
} else {
    echo "Erro: Usuário não encontrado!";
    exit();
}

// Buscar os dados dos filmes
$sql_filmes = "SELECT filmes.id, filmes.imagem, filmes.titulo, filmes.descricao, filmes.ano, filmes.url, genero.nome AS genero,
               IFNULL(AVG(avaliacao.nota), 0) AS media_avaliacao
               FROM filmes
               JOIN filmes_genero ON filmes.id = filmes_genero.id_filmes
               JOIN genero ON filmes_genero.id_genero = genero.id
               LEFT JOIN avaliacao ON filmes.id = avaliacao.filmes_avaliacao
               GROUP BY filmes.id";
$stmt = $conn->prepare($sql_filmes);
$stmt->execute();
$result_filmes = $stmt->get_result();

$imagens = [];
if ($result_filmes->num_rows > 0) {
    while ($row = $result_filmes->fetch_assoc()) {
        $imagens[] = array(
            'id' => $row['id'], // ID do filme necessário para relacionar a avaliação
            'imagem' => base64_encode($row['imagem']),
            'titulo' => $row['titulo'],
            'descricao' => $row['descricao'],
            'ano' => $row['ano'],
            'genero' => $row['genero'],
            'url' => $row['url'],
            'media_avaliacao' => $row['media_avaliacao']
        );
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GenesFlix</title>
    <link rel="stylesheet" href="styles/home_styles.css">
    <style>
        /* Estilo do modal de detalhes */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            background-color: #1c1c1c;
            padding: 30px;
            border-radius: 10px;
            width: 80%;
            max-width: 1000px;
            position: relative;
        }

        .modal-content h2 {
            color: #fff;
        }

        .modal-content p {
            color: #ccc;
        }

        .close-modal {
            position: absolute;
            top: 10px;
            right: 20px;
            background: none;
            border: none;
            font-size: 25px;
            color: white;
            cursor: pointer;
        }

        .play-button {
            display: inline-block;
            background-color: #6106f4;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 20px;
        }

        .play-button:hover {
            background-color: #6106f471;
        }

        /* Estilos para o sistema de avaliação */
        .rating-container {
            text-align: left;
            background-color: #2d2d2d;
            /* Cinza escuro */
            padding: 20px;
            border-radius: 8px;
            color: white;
            margin-top: 20px;
        }

        .stars {
            display: flex;
            justify-content: left;
            gap: 10px;
        }

        .star {
            font-size: 25px;
            cursor: pointer;
            color: #ccc;
            /* Cinza por padrão */
            transition: color 0.3s;
        }

        .star:hover,
        .star.active {
            color: #ffc107;
            /* Amarelo para estrelas selecionadas */
        }

        .rating-text {
            margin-top: 15px;
            font-size: 15px;
        }

        #submit-rating {
            background-color: #6106f4;
            /* Mesma cor do botão de 'Assistir' */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        #submit-rating:hover {
            background-color: #4b04b9;
            /* Cor mais escura ao passar o mouse */
        }

        /* Ajuste para alinhar o botão */
        .rating-container {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            margin-top: 20px;
        }

        .estrela {
            color: yellow;
            font-size: 1em;
            /* Menor que o original */
            vertical-align: baseline;
            margin-right: 5px;
        }

        .filme p {
            font-size: 1em;
            font-weight: bold;
            /* Aplica negrito */
            color: #555;
            display: flex;
            align-items: center;
            /* Adiciona um pouco de espaço entre o texto e a borda do container */
            margin: 0;
        }

        .filme {
            position: relative;
            padding: 10px;
            border: 1px solid black;
            border-radius: 8px;
            margin: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .btn {
            text-align: center;
        }

        .btn-link {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: rgb(0, 0, 0);
            background-color: #eeff00;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn-link:hover {
            background-color: #eeff0088;
            transform: scale(1.05);
        }

        .btn-link:active {
            background-color: #eeff00c9;
        }

        .video-container {
            width: 100%;
            height: 400px;
            margin-top: 20px;
            display: none;
            /* Oculto até o botão "Assistir" ser clicado */
        }
    </style>
</head>
<body>
<div class="header">
        <div class="header-left">
            <img src="img/logo_title.png">
        </div>
        <nav class="navbar">
            <a href="Home.php">Início</a>
            <a href="#">Originais</a>
            <a href="#">Adicionados recentemente</a>
            <a href="#">Minha lista</a>
        </nav>
        <div class="search-bar">
            <span class="search-icon">🔎</span>
            <input type="text" class="search-input" placeholder="legendas em português">
        </div>
        <div class="user-info">
            <h4 class="user-name"><?php echo htmlspecialchars($user['full_name']); ?></h4>
            <div class="header-right color-border">
                <a href="profile.php">
                    <?php
                    $imgData = base64_encode($user['profile_picture']);
                    ?>
                    <img src="data:image/jpeg;base64,<?php echo $imgData; ?>" alt="Foto de Perfil" class="profile-thumbnail">
                </a>
            </div>
        </div>
    </div>
    <br><br>

    <main>
        <div class="filme-container">
            <?php foreach ($imagens as $imagem) { ?>
                <div class="filme" data-id="<?= htmlspecialchars($imagem['id']) ?>" data-titulo="<?= htmlspecialchars($imagem['titulo']) ?>" data-descricao="<?= htmlspecialchars($imagem['descricao']) ?>" data-data-lancamento="<?= htmlspecialchars($imagem['ano']) ?>" data-genero="<?= htmlspecialchars($imagem['genero']) ?>" data-url="<?= htmlspecialchars($imagem['url']) ?>" data-media-avaliacao="<?= number_format($imagem['media_avaliacao'], 2) ?>"> <!-- Passando a nota média aqui -->
                    <img src="data:image/jpeg;base64,<?= $imagem['imagem'] ?>" alt="<?= htmlspecialchars($imagem['titulo']) ?>">
                    <h2><?= htmlspecialchars($imagem['titulo']) ?></h2>
                    <p><span class="estrela">&#9733;</span><?= number_format($imagem['media_avaliacao'], 2) ?></p> <!-- Exibe a média diretamente -->
                </div>
            <?php } ?>
        </div>
    </main>

    <!-- Modal de Detalhes -->
    <div class="modal" id="filmeModal">
        <div class="modal-content">
            <button class="close-modal" id="closeModal">&times;</button>
            <h2 id="modalTitulo"></h2>
            <p id="modalGenero"></p>
            <p id="modalDataLancamento"></p>
            <p id="modalDescricao"></p>
            <p id="modalNota"></p> <!-- Exibe a nota média -->
            <button class="play-button" id="playButton">Assistir</button>
            <!-- Contêiner de vídeo -->
            <div class="video-container" id="videoContainer">
                <iframe id="videoPlayer" width="100%" height="100%" frameborder="0" allowfullscreen></iframe>
            </div>
            <br>
            <!-- Sistema de avaliação -->
            <div class="rating-container">
                <h3>Avalie este filme:</h3>
                <div class="stars">
                    <span class="star" data-value="1">&#9733;</span>
                    <span class="star" data-value="2">&#9733;</span>
                    <span class="star" data-value="3">&#9733;</span>
                    <span class="star" data-value="4">&#9733;</span>
                    <span class="star" data-value="5">&#9733;</span>
                </div>
                <p>Sua Avaliação: <span id="rating-value">0</span> estrela(s)</p>
                <button id="submit-rating">Enviar Avaliação</button>
            </div>
        </div>
    </div>
    <br>
    <div class="botao">
        <a href="logout.php" class="button-link">Sair</a>
    </div>
    <br>
    <div class="btn">
        <?php if ($user['role'] == 'admin') : ?>
            <a href="cadastro_de_filme.php" class="btn-link">Opção de Admin: Cadastrar Filme</a>
        <?php endif; ?>
    </div>
    <br>
    <footer class="footer">
        <p>&copy; 2024 GenesFlix, Inc. <a href="#">Política de Privacidade</a> • <a href="#">Termos de Serviço</a></p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            fetch('Home.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const filmeContainer = document.querySelector('.filme-container');
                        data.filmes.forEach(filme => {
                            // Cria a div do filme
                            const filmeDiv = document.createElement('div');
                            filmeDiv.className = 'filme';
                            filmeDiv.dataset.id = filme.id;
                            filmeDiv.dataset.titulo = filme.titulo;
                            filmeDiv.dataset.descricao = filme.descricao;
                            filmeDiv.dataset.dataLancamento = filme.ano;
                            filmeDiv.dataset.genero = filme.genero;
                            filmeDiv.dataset.url = filme.url; // Adicionar URL do filme
                            filmeDiv.dataset.mediaAvaliacao = filme.media_avaliacao;

                            // Conteúdo HTML do filme
                            filmeDiv.innerHTML = `
                        <img src="data:image/jpeg;base64,${filme.imagem}" alt="${filme.titulo}">
                        <h2>${filme.titulo}</h2>
                        <p>Nota: ${parseFloat(filme.media_avaliacao).toFixed(2)}</p>
                    `;
                            filmeContainer.appendChild(filmeDiv);
                        });
                    } else {
                        console.error('Erro ao carregar filmes');
                    }
                })
                .catch(error => console.error('Erro:', error));

            const modal = document.getElementById('filmeModal');
            const closeModal = document.getElementById('closeModal');
            const modalTitulo = document.getElementById('modalTitulo');
            const modalGenero = document.getElementById('modalGenero');
            const modalDataLancamento = document.getElementById('modalDataLancamento');
            const modalDescricao = document.getElementById('modalDescricao');
            const modalNota = document.getElementById('modalNota');
            const playButton = document.getElementById('playButton');
            const videoContainer = document.getElementById('videoContainer');
            const videoPlayer = document.getElementById('videoPlayer');
            const stars = document.querySelectorAll('.star');
            const ratingValue = document.getElementById('rating-value');
            const submitRating = document.getElementById('submit-rating');

            let selectedRating = 0;
            let selectedFilmId = 0;

            // Função para resetar a avaliação
            function resetRating() {
                ratingValue.textContent = '0';
                selectedRating = 0;
                stars.forEach(star => star.classList.remove('active'));
            }

            // Adiciona listeners para estrelas de avaliação
            stars.forEach(star => {
                star.addEventListener('click', () => {
                    const rating = star.getAttribute('data-value');
                    ratingValue.textContent = rating;
                    selectedRating = rating;
                    stars.forEach(s => s.classList.remove('active'));
                    for (let i = 0; i < rating; i++) {
                        stars[i].classList.add('active');
                    }
                });
            });

            // Exibir modal ao clicar em um filme
            document.querySelector('.filme-container').addEventListener('click', e => {
                const filme = e.target.closest('.filme');
                if (filme) {
                    const titulo = filme.dataset.titulo;
                    const descricao = filme.dataset.descricao;
                    const dataLancamento = filme.dataset.dataLancamento;
                    const genero = filme.dataset.genero;
                    const mediaAvaliacao = filme.dataset.mediaAvaliacao; // Captura a nota média
                    const url = filme.dataset.url;
                    selectedFilmId = filme.dataset.id;

                    // Preencher o modal com os detalhes do filme
                    modalTitulo.textContent = titulo;
                    modalGenero.innerHTML = `<strong>Gênero:</strong> ${genero}`;
                    modalDataLancamento.innerHTML = `<strong>Lançamento:</strong> ${dataLancamento}`;
                    modalDescricao.innerHTML = `<strong>Descrição:</strong> ${descricao}`;
                    modalNota.innerHTML = `<strong>Nota Média:</strong> ${mediaAvaliacao}`; // Exibe a nota média corretamente

                    // Configura o botão "Assistir" para exibir o vídeo
                    playButton.onclick = function() {
                        // Verifica se a URL é do YouTube ou um link de vídeo local
                        if (url.includes('youtube.com') || url.includes('youtu.be')) {
                            const youtubeId = url.split('v=')[1] || url.split('youtu.be/')[1];
                            videoPlayer.src = `https://www.youtube.com/embed/${youtubeId}`;
                        } else {
                            videoPlayer.src = url; // URL local ou outra URL
                        }
                        videoContainer.style.display = 'block'; // Exibir o vídeo
                    };

                    // Exibir o modal
                    modal.classList.add('show');
                }
            });

            // Fechar o modal ao clicar no botão X
            closeModal.addEventListener('click', () => {
                modal.classList.remove('show');
                videoPlayer.src = ''; // Limpar o vídeo ao fechar o modal
                videoContainer.style.display = 'none';
            });

            // Fechar o modal ao clicar fora do conteúdo
            window.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('show');
                    videoPlayer.src = ''; // Limpar o vídeo ao fechar o modal
                    videoContainer.style.display = 'none';
                }
            });
        
        
        // Enviar a avaliação
        submitRating.addEventListener('click', () => {
        const rating = ratingValue.textContent;
        const filmeTitulo = modalTitulo.textContent;

        if (rating === '0') {
            alert('Por favor, escolha uma estrela para enviar a avaliação.');
            return;
        }

        fetch('submit_rating.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    rating: rating,
                    filme: filmeTitulo
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Avaliação enviada com sucesso!');
                    resetRating();
                } else {
                    alert('Erro ao enviar avaliação.');
                    resetRating();
                }
            })
            .catch((error) => {
                console.error('Erro:', error);
                alert('Ocorreu um erro ao enviar a avaliação.');
            });
        });
        
    });
    </script>
</body>
</html>

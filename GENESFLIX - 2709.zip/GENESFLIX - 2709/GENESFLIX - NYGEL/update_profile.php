<?php
session_start();
require 'conexao.php'; // Inclui a conexão com o banco de dados

// Verifique se o usuário está logado
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Atualize os dados do usuário no banco de dados
    $sql = "UPDATE users SET full_name = ?, email = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssi', $name, $email, $user_id);

    if ($stmt->execute()) {
        $message = "Perfil atualizado com sucesso!";
    } else {
        $message = "Erro ao atualizar perfil!";
    }

    $stmt->close();
    $conn->close();

    // Redireciona para a página de mensagem
    header("Location: profile_update_message.php?message=" . urlencode($message));
    exit();
}
?>

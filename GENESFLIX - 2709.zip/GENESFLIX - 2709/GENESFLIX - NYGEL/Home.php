<?php
session_start();
require 'conexao.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user'];

// Buscar os dados do usuário
$sql_user = "SELECT full_name, email, profile_picture, role FROM users WHERE id = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result_user = $stmt->get_result();

if ($result_user->num_rows > 0) {
    $user = $result_user->fetch_assoc();
} else {
    echo "Erro: Usuário não encontrado!";
    exit();
}

// Buscar os dados dos filmes
$sql_filmes = "SELECT 
filmes.id, 
filmes.imagem, 
filmes.titulo, 
filmes.descricao, 
filmes.ano, 
filmes.url, 
genero.nome AS genero,
IFNULL(AVG(avaliacao.nota), 0) AS media_avaliacao
FROM 
filmes
JOIN 
filmes_genero ON filmes.id = filmes_genero.id_filmes
JOIN 
genero ON filmes_genero.id_genero = genero.id
LEFT JOIN 
avaliacao ON filmes.id = avaliacao.filmes_avaliacao
GROUP BY 
filmes.id;
";
$stmt = $conn->prepare($sql_filmes);
$stmt->execute();
$result_filmes = $stmt->get_result();

$imagens = [];
if ($result_filmes->num_rows > 0) {
    while ($row = $result_filmes->fetch_assoc()) {
        $imagens[] = array(
            'id' => $row['id'], // ID do filme necessário para relacionar a avaliação
            'imagem' => base64_encode($row['imagem']),
            'titulo' => $row['titulo'],
            'descricao' => $row['descricao'],
            'ano' => $row['ano'],
            'genero' => $row['genero'],
            'url' => $row['url'],
            'media_avaliacao' => $row['media_avaliacao']
        );
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GenesFlix</title>
    <link rel="stylesheet" href="styles/home_styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* Estilo do modal de detalhes */
        /* Bloqueia a rolagem do fundo da página */
        body.no-scroll {
            overflow: hidden;
        }

        /* Configurações gerais do modal */
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            overflow: auto;
            /* Permite a rolagem do conteúdo interno */
        }

        /* Exibe o modal quando ativo */
        .modal.show {
            display: flex;
        }

        /* Estilização do conteúdo do modal */
        .modal-content {
            background-color: #1c1c1c;
            padding: 30px;
            border-radius: 10px;
            width: 80%;
            max-width: 1000px;
            max-height: 90%;
            /* Limita a altura para permitir rolagem */
            overflow-y: auto;
            /* Permite rolagem no modal se o conteúdo for maior que a altura */
            position: relative;
        }

        /* Estilos para o título no modal */
        .modal-content h2 {
            color: #fff;
        }

        /* Estilos para os parágrafos no modal */
        .modal-content p {
            color: #ccc;
        }

        /* Botão de fechar modal */
        .close-modal {
            position: absolute;
            top: 10px;
            right: 20px;
            background: none;
            border: none;
            font-size: 25px;
            color: white;
            cursor: pointer;
        }

        .play-button {
            display: inline-block;
            background-color: #6106f4;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 20px;
        }

        .play-button:hover {
            background-color: #6106f471;
        }

        /* Estilos para o sistema de avaliação */
        .rating-container {
            text-align: left;
            background-color: #2d2d2d;
            /* Cinza escuro */
            padding: 20px;
            border-radius: 8px;
            color: white;
            margin-top: 20px;
        }

        .stars {
            display: flex;
            justify-content: left;
            gap: 10px;
        }

        .star {
            font-size: 25px;
            cursor: pointer;
            color: #ccc;
            /* Cinza por padrão */
            transition: color 0.3s;
        }

        .star:hover,
        .star.active {
            color: #ffc107;
            /* Amarelo para estrelas selecionadas */
        }

        .rating-text {
            margin-top: 15px;
            font-size: 15px;
        }

        #submit-rating {
            background-color: #6106f4;
            /* Mesma cor do botão de 'Assistir' */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        #submit-rating:hover {
            background-color: #4b04b9;
            /* Cor mais escura ao passar o mouse */
        }

        /* Ajuste para alinhar o botão */
        .rating-container {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            margin-top: 20px;
        }

        .estrela {
            color: yellow;
            font-size: 1em;
            /* Menor que o original */
            vertical-align: baseline;
            margin-right: 5px;
        }

        .filme p {
            font-size: 1em;
            font-weight: bold;
            /* Aplica negrito */
            color: #555;
            display: flex;
            align-items: center;
            /* Adiciona um pouco de espaço entre o texto e a borda do container */
            margin: 0;
        }

        .filme {
            position: relative;
            padding: 10px;
            border: 1px solid black;
            border-radius: 8px;
            margin: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .estrela {
            font-size: 25px;
            cursor: pointer;
            color: #ccc;
            position: absolute;
            bottom: 10px;
            right: 10px;
        }

        .estrela:hover,
        .estrela.active {
            color: green;
        }

        /* */

        .btn {
            text-align: center;
        }

        .btn-link {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: rgb(0, 0, 0);
            background-color: #eeff00;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn-link:hover {
            background-color: #eeff0088;
            transform: scale(1.05);
        }

        .btn-link:active {
            background-color: #eeff00c9;
        }

        .video-container {
            width: 100%;
            height: 400px;
            margin-top: 20px;
            display: none;
            /* Oculto até o botão "Assistir" ser clicado */
        }

        .search-bar {
            position: relative;
            width: 250px;
            margin-left: 20px;
        }

        .search-bar input {
            width: 200px;
            padding: 10px 40px 10px 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            background-color: #e0e0e0;
            color: #333;
        }

        .search-bar input:focus {
            outline: none;
            border-color: #6106f4;
        }

        .search-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            color: #000;
            /* Ícone de lupa preto */
        }

        /* Sugestões de pesquisa */
        .suggestions {
            position: absolute;
            width: 250px;
            max-height: 150px;
            overflow-y: auto;
            margin: 0;
            padding: 0;
            list-style-type: none;
            background-color: #fff;
            border: 1px solid #000;
            border-radius: 5px;
            z-index: 1000;
            top: 55px;
            /* Distância da barra de pesquisa */
        }

        .suggestions li {
            padding: 10px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .suggestions li:hover {
            background-color: #f0f0f0;
        }

        .suggestions li:last-child {
            border-bottom: none;
        }

        .titulo_h2 {
            padding: 10px 20px;
            color: rgba(255, 255, 255, 0.719);
            font-size: 25px;
            margin-bottom: 20px;
            box-shadow: 5px 5px 5px rgba(2, 2, 2, 2.2);
            flex-basis: 100%;
            text-align: center;
        }

        /* Estilizando a barra de rolagem para navegadores baseados em WebKit */
        ::-webkit-scrollbar {
            width: 12px;
            /* Largura da barra de rolagem */
        }

        /* Cor do fundo da barra de rolagem */
        ::-webkit-scrollbar-track {
            background: #1a1a1a;
            /* Cor de fundo da track */
        }

        /* Cor da "thumb" da barra de rolagem (a parte que se move) */
        ::-webkit-scrollbar-thumb {
            background-color: #6c5ce7;
            /* Cor da thumb */
            border-radius: 10px;
            /* Deixar a thumb com cantos arredondados */
            border: 3px solid #2d3436;
            /* Adicionar uma borda ao redor da thumb */
        }

        /* Ao passar o mouse sobre a thumb */
        ::-webkit-scrollbar-thumb:hover {
            background-color: #8e44ad;
            /* Cor da thumb ao passar o mouse */
        }

        /* Barra de rolagem mais fina para Mozilla Firefox */
        * {
            scrollbar-width: thin;
            scrollbar-color: #6c5ce7 #1a1a1a;
            /* Cor da thumb e track, respectivamente */
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="header-left">
            <img src="img/logo_title.png">
        </div>
        <nav class="navbar">
            <a href="Home.php">Início</a>
            <a href="#">Originais</a>
            <a href="#">Adicionados recentemente</a>
            <a href="favoritos.php">Minha lista</a>
        </nav>
        <!-- Barra de pesquisa -->
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Pesquise..." autocomplete="off">
            <ul id="suggestions" class="suggestions"></ul>
            <i class="fa fa-search search-icon"></i>
        </div>
        <div class="user-info">
            <h4 class="user-name"><?php echo htmlspecialchars($user['full_name']); ?></h4>
            <div class="header-right color-border">
                <a href="profile.php">
                    <?php
                    $imgData = base64_encode($user['profile_picture']);
                    ?>
                    <img src="data:image/jpeg;base64,<?php echo $imgData; ?>" alt="Foto de Perfil" class="profile-thumbnail">
                </a>
            </div>
        </div>
    </div>
    <main>
        <div class="filme-container">
            <h2 class="titulo_h2">Filmes</h2>
            <?php foreach ($imagens as $imagem) { ?>
                <div class="filme" data-id="<?= htmlspecialchars($imagem['id']) ?>" data-titulo="<?= htmlspecialchars($imagem['titulo']) ?>" data-descricao="<?= htmlspecialchars($imagem['descricao']) ?>" data-data-lancamento="<?= htmlspecialchars($imagem['ano']) ?>" data-genero="<?= htmlspecialchars($imagem['genero']) ?>" data-url="<?= htmlspecialchars($imagem['url']) ?>" data-media-avaliacao="<?= number_format($imagem['media_avaliacao'], 2) ?>"> <!-- Passando a nota média aqui -->
                    <img src="data:image/jpeg;base64,<?= $imagem['imagem'] ?>" alt="<?= htmlspecialchars($imagem['titulo']) ?>">
                    <h2><?= htmlspecialchars($imagem['titulo']) ?></h2>
                    <br>
                    <span style="font-size: 15px;" class="estrela" data-id="<?= htmlspecialchars($imagem['id']) ?>" onclick="favoritarFilme(<?= htmlspecialchars($imagem['id']) ?>)">Listar &#10010;</span>
                </div>
            <?php } ?>
        </div>
    </main>

    <!-- Modal de Detalhes -->
    <div class="modal" id="filmeModal">
        <div class="modal-content">
            <button class="close-modal" id="closeModal">&times;</button>
            <h2 id="modalTitulo"></h2>
            <p id="modalGenero"></p>
            <p id="modalDataLancamento"></p>
            <p id="modalDescricao"></p>
            <p id="modalNota"></p> <!-- Exibe a nota média -->
            <button class="play-button" id="playButton">Assistir</button>
            <!-- Contêiner de vídeo -->
            <div class="video-container" id="videoContainer">
                <iframe id="videoPlayer" width="100%" height="100%" frameborder="0" allowfullscreen></iframe>
            </div>
            <br>
            <!-- Sistema de avaliação -->
            <div class="rating-container">
                <h3>Avalie este filme:</h3>
                <div class="stars">
                    <span class="star" data-value="1">&#9733;</span>
                    <span class="star" data-value="2">&#9733;</span>
                    <span class="star" data-value="3">&#9733;</span>
                    <span class="star" data-value="4">&#9733;</span>
                    <span class="star" data-value="5">&#9733;</span>
                </div>
                <p>Sua Avaliação: <span id="rating-value">0</span> estrela(s)</p>
                <button id="submit-rating">Enviar Avaliação</button>
            </div>
        </div>
    </div>
    <br>
    <br>
    <div class="btn">
        <?php if ($user['role'] == 'admin') : ?>
            <a href="cadastro_de_filme.php" class="btn-link">Opção de Admin: Cadastrar Filme</a>
        <?php endif; ?>
    </div>
    <br>
    <footer class="footer">
        <p>&copy; 2024 GenesFlix, Inc. <a href="#">Política de Privacidade</a> • <a href="#">Termos de Serviço</a></p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Função para favoritar um filme
            function favoritarFilme(filmeId) {
                fetch('favoritar.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            filme_id: filmeId
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Filme favoritado com sucesso!');
                        } else {
                            alert('Erro ao favoritar filme.');
                        }
                    })
                    .catch(error => {
                        console.error('Erro:', error);
                        alert('Erro ao favoritar filme.');
                    });
            }

            // Carregar filmes e exibir na tela
            fetch('Home.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const filmeContainer = document.querySelector('.filme-container');
                        data.filmes.forEach(filme => {
                            const filmeDiv = document.createElement('div');
                            filmeDiv.className = 'filme';
                            filmeDiv.dataset.id = filme.id;
                            filmeDiv.dataset.titulo = filme.titulo;
                            filmeDiv.dataset.descricao = filme.descricao;
                            filmeDiv.dataset.dataLancamento = filme.ano;
                            filmeDiv.dataset.genero = filme.genero;
                            filmeDiv.dataset.url = filme.url;
                            filmeDiv.dataset.mediaAvaliacao = filme.media_avaliacao;

                            // Conteúdo HTML do filme
                            filmeDiv.innerHTML = `
                        <img src="data:image/jpeg;base64,${filme.imagem}" alt="${filme.titulo}">
                        <h2>${filme.titulo}</h2>
                        <p>Nota: ${parseFloat(filme.media_avaliacao).toFixed(2)}</p>
                    `;
                            filmeContainer.appendChild(filmeDiv);
                        });
                    } else {
                        console.error('Erro ao carregar filmes');
                    }
                })
                .catch(error => console.error('Erro:', error));

            // Referências do modal
            const modal = document.getElementById('filmeModal');
            const closeModal = document.getElementById('closeModal');
            const modalTitulo = document.getElementById('modalTitulo');
            const modalGenero = document.getElementById('modalGenero');
            const modalDataLancamento = document.getElementById('modalDataLancamento');
            const modalDescricao = document.getElementById('modalDescricao');
            const modalNota = document.getElementById('modalNota');
            const playButton = document.getElementById('playButton');
            const videoContainer = document.getElementById('videoContainer');
            const videoPlayer = document.getElementById('videoPlayer');
            const stars = document.querySelectorAll('.star');
            const ratingValue = document.getElementById('rating-value');
            const submitRating = document.getElementById('submit-rating');
            let selectedRating = 0;
            let selectedFilmId = 0;

            // Função para resetar a avaliação
            function resetRating() {
                ratingValue.textContent = '0';
                selectedRating = 0;
                stars.forEach(star => star.classList.remove('active'));
            }

            // Adiciona listeners para estrelas de avaliação
            stars.forEach(star => {
                star.addEventListener('click', () => {
                    const rating = star.getAttribute('data-value');
                    ratingValue.textContent = rating;
                    selectedRating = rating;
                    stars.forEach(s => s.classList.remove('active'));
                    for (let i = 0; i < rating; i++) {
                        stars[i].classList.add('active');
                    }
                });
            });

            // Exibir modal ao clicar em um filme
            document.querySelector('.filme-container').addEventListener('click', e => {
                const filme = e.target.closest('.filme');
                if (filme) {
                    const titulo = filme.dataset.titulo;
                    const descricao = filme.dataset.descricao;
                    const dataLancamento = filme.dataset.dataLancamento;
                    const genero = filme.dataset.genero;
                    const mediaAvaliacao = filme.dataset.mediaAvaliacao;
                    const url = filme.dataset.url;
                    selectedFilmId = filme.dataset.id;

                    // Preencher o modal com os detalhes do filme
                    modalTitulo.textContent = titulo;
                    modalGenero.innerHTML = `<strong>Gênero:</strong> ${genero}`;
                    modalDataLancamento.innerHTML = `<strong>Lançamento:</strong> ${dataLancamento}`;
                    modalDescricao.innerHTML = `<strong>Descrição:</strong> ${descricao}`;
                    modalNota.innerHTML = `<strong>Nota Média:</strong> ${mediaAvaliacao}`;

                    // Configura o botão "Assistir" para exibir o vídeo
                    playButton.onclick = function() {
                        if (url.includes('youtube.com') || url.includes('youtu.be')) {
                            const youtubeId = url.split('v=')[1] || url.split('youtu.be/')[1];
                            videoPlayer.src = `https://www.youtube.com/embed/${youtubeId}`;
                        } else if (url.includes('drive.google.com')) {
                            const driveId = url.split('/d/')[1].split('/')[0];
                            videoPlayer.src = `https://drive.google.com/file/d/${driveId}/preview`;
                        } else {
                            videoPlayer.src = url;
                        }
                        videoContainer.style.display = 'block';
                    };

                    // Exibir o modal e bloquear a rolagem do fundo
                    modal.classList.add('show');
                    document.body.classList.add('no-scroll');
                }
            });

            // Fechar o modal ao clicar no botão X
            closeModal.addEventListener('click', () => {
                modal.classList.remove('show');
                document.body.classList.remove('no-scroll');
                videoPlayer.src = ''; // Limpar o vídeo ao fechar o modal
                videoContainer.style.display = 'none';
            });

            // Fechar o modal ao clicar fora do conteúdo
            window.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('show');
                    document.body.classList.remove('no-scroll');
                    videoPlayer.src = ''; // Limpar o vídeo ao fechar o modal
                    videoContainer.style.display = 'none';
                }
            });

            // Enviar a avaliação
            submitRating.addEventListener('click', () => {
                const rating = ratingValue.textContent;
                const filmeTitulo = modalTitulo.textContent;

                if (rating === '0') {
                    alert('Por favor, escolha uma estrela para enviar a avaliação.');
                    return;
                }

                fetch('submit_rating.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            rating: rating,
                            filme: filmeTitulo
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Avaliação enviada com sucesso!');
                            resetRating();
                        } else {
                            alert('Você já avaliou este filme.');
                            resetRating();
                        }
                    })
                    .catch(error => {
                        console.error('Erro:', error);
                        alert('Ocorreu um erro ao enviar a avaliação.');
                    });
            });

            // Função para buscar sugestões enquanto o usuário digita
            document.getElementById('searchInput').addEventListener('input', function() {
                const query = this.value;

                if (query.length > 0) {
                    fetch(`search_suggestions.php?query=${query}`)
                        .then(response => response.json())
                        .then(data => {
                            const suggestionsList = document.getElementById('suggestions');
                            suggestionsList.innerHTML = ''; // Limpa as sugestões anteriores
                            data.forEach(filme => {
                                const listItem = document.createElement('li');
                                listItem.textContent = filme.titulo;

                                // Autocompleta o campo de pesquisa ao clicar na sugestão
                                listItem.addEventListener('click', function() {
                                    document.getElementById('searchInput').value = filme.titulo;
                                    window.location.href = `search_results.php?query=${filme.titulo}`;
                                });

                                suggestionsList.appendChild(listItem);
                            });
                        });
                } else {
                    document.getElementById('suggestions').innerHTML = ''; // Limpa as sugestões se o campo estiver vazio
                }
            });

            // Função para redirecionar o usuário ao pressionar ENTER
            document.getElementById('searchInput').addEventListener('keydown', function(event) {
                if (event.key === 'Enter') {
                    const query = this.value;
                    if (query.length > 0) {
                        window.location.href = `search_results.php?query=${query}`;
                    }
                }
            });
        });
    </script>
</body>

</html>
document.addEventListener('DOMContentLoaded', function () {
    // Carregar filmes via fetch
    fetch('Home.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const filmeContainer = document.querySelector('.filme-container');
                data.filmes.forEach(filme => {
                    // Cria a div do filme
                    const filmeDiv = document.createElement('div');
                    filmeDiv.className = 'filme';
                    filmeDiv.dataset.id = filme.id;
                    filmeDiv.dataset.titulo = filme.titulo;
                    filmeDiv.dataset.descricao = filme.descricao;
                    filmeDiv.dataset.dataLancamento = filme.ano;
                    filmeDiv.dataset.genero = filme.genero;
                    filmeDiv.dataset.url = filme.url; // Adicionar URL do filme
                    filmeDiv.dataset.mediaAvaliacao = filme.media_avaliacao;

                    // Conteúdo HTML do filme
                    filmeDiv.innerHTML = `
                        <img src="data:image/jpeg;base64,${filme.imagem}" alt="${filme.titulo}">
                        <h2>${filme.titulo}</h2>
                        <p>Nota: ${parseFloat(filme.media_avaliacao).toFixed(2)}</p>
                    `;
                    filmeContainer.appendChild(filmeDiv);
                });
            } else {
                console.error('Erro ao carregar filmes');
            }
        })
        .catch(error => console.error('Erro:', error));

    // Seleciona os elementos do modal
    const modal = document.getElementById('filmeModal');
    const closeModal = document.getElementById('closeModal');
    const modalTitulo = document.getElementById('modalTitulo');
    const modalGenero = document.getElementById('modalGenero');
    const modalDataLancamento = document.getElementById('modalDataLancamento');
    const modalDescricao = document.getElementById('modalDescricao');
    const modalNota = document.getElementById('modalNota');
    const playButton = document.getElementById('playButton');
    const videoPlayer = document.getElementById('videoPlayer');
    const stars = document.querySelectorAll('.star');
    const ratingValue = document.getElementById('rating-value');
    const submitRating = document.getElementById('submit-rating');
    let selectedRating = 0;

    // Função para resetar a avaliação
    function resetRating() {
        ratingValue.textContent = '0';
        selectedRating = 0;
        stars.forEach(star => star.classList.remove('active'));
    }

    // Adiciona listeners para estrelas de avaliação
    stars.forEach(star => {
        star.addEventListener('click', () => {
            const rating = star.getAttribute('data-value');
            ratingValue.textContent = rating;
            selectedRating = rating;
            stars.forEach(s => s.classList.remove('active'));
            for (let i = 0; i < rating; i++) {
                stars[i].classList.add('active');
            }
        });
    });

    // Exibir modal ao clicar em um filme
    document.querySelector('.filme-container').addEventListener('click', e => {
        const filme = e.target.closest('.filme');
        if (filme) {
            const titulo = filme.dataset.titulo;
            const descricao = filme.dataset.descricao;
            const dataLancamento = filme.dataset.dataLancamento;
            const genero = filme.dataset.genero;
            const mediaAvaliacao = parseFloat(filme.dataset.mediaAvaliacao);
            const url = filme.dataset.url; // Obter URL do filme

            // Preencher o modal com os detalhes do filme
            modalTitulo.textContent = titulo;
            modalGenero.innerHTML = `<strong>Gênero:</strong> ${genero}`;
            modalDataLancamento.innerHTML = `<strong>Lançamento:</strong> ${dataLancamento}`;
            modalDescricao.innerHTML = `<strong>Descrição:</strong> ${descricao}`;
            modalNota.innerHTML = `<strong>Nota Média:</strong> ${isNaN(mediaAvaliacao) ? 'N/A' : mediaAvaliacao.toFixed(2)}`;

            resetRating();

            // Atualiza o botão "Assistir" para iniciar o filme
            playButton.onclick = function () {
                videoPlayer.src = url; // Definir URL do filme no iframe
                videoPlayer.style.display = 'block';
            };

            // Exibir o modal
            modal.classList.add('show');
        }
    });

    // Fechar o modal ao clicar no botão X
    closeModal.addEventListener('click', () => {
        modal.classList.remove('show');
        videoPlayer.src = ''; // Limpar o vídeo ao fechar o modal
    });

    // Fechar o modal ao clicar fora do conteúdo
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('show');
            videoPlayer.src = ''; // Limpar o vídeo ao fechar o modal
        }
    });

    // Enviar a avaliação
    submitRating.addEventListener('click', () => {
        const rating = ratingValue.textContent;
        const filmeTitulo = modalTitulo.textContent;

        if (rating === '0') {
            alert('Por favor, escolha uma estrela para enviar a avaliação.');
            return;
        }

        fetch('submit_rating.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                rating: rating,
                filme: filmeTitulo
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Avaliação enviada com sucesso!');
            } else {
                alert('Erro ao enviar avaliação.');
            }
        })
        .catch((error) => {
            console.error('Erro:', error);
            alert('Ocorreu um erro ao enviar a avaliação.');
        });
    });
});
